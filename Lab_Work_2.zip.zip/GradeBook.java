
public class GradeBook {

    String studentName;
    int assignmentScore;
    int examScore;
    double finalGrade;

    // Constructor
    public GradeBook(String name, int aScore, int eScore) {
        studentName = name;
        assignmentScore = aScore;
        examScore = eScore;
    }

    // Calculate final grade
    public void calculateResult() {
        finalGrade = (double) assignmentScore * 0.40
                + (double) examScore * 0.60;
    }

    // Display student report
    public void displaySummary() {
        System.out.println("Name:\t" + studentName);
        System.out.println("Raw Scores:\t" + assignmentScore
                + " | " + examScore);
        System.out.println("Final Weighted Grade:\t"
                + finalGrade + "%");
    }

    public static void main(String[] args) {
        GradeBook student = new GradeBook("Alex", 85, 90);

        student.calculateResult();
        student.displaySummary();
    }
}
