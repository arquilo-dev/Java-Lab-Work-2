
public class SyntaxDrills {
    public static void main(String[] args) {

        // TASK 1: Identifier Validation
        int age = 18;
        double price = 25.5;
        String studentName = "Alex";

        // int 1number = 10; // Cannot start with a digit
        // int my-name = 5; // Hyphens are not allowed
        // int class = 3; // "class" is a reserved keyword

        System.out.println("Task 1: " + age + ", " + price + ", " + studentName);


        // TASK 2: Case Sensitivity
        int score = 10;
        int Score = 20;
        int SCORE = 30;

        System.out.println("\nTask 2:");
        System.out.println(score);
        System.out.println(Score);
        System.out.println(SCORE);


        // TASK 3: The Constant
        final int MAX_VALUE = 100;

        // MAX_VALUE = 200; // Error: cannot assign a value to a final variable

        System.out.println("\nTask 3: " + MAX_VALUE);


        // TASK 4: Floating Point Suffixes
        // float number = 10.5; // Error: double cannot be converted to float
        float number = 10.5f; // The 'f' specifies a float literal

        System.out.println("\nTask 4: " + number);


        // TASK 5: String vs Char
        char c = 'A';
        String s = "A";

        //  c = s; // Error: String cannot be converted to char
        //  s = c; // Error: char cannot be converted to String

        System.out.println("\nTask 5:");
        System.out.println(c);
        System.out.println(s);


        // TASK 6: Integer Truncation
        int a = 10;
        int b = 3;
        double result = a / b;

        // Integer division happens before conversion to double
        System.out.println("\nTask 6: " + result);


        // TASK 7: Implicit Widening
        byte smallNumber = 50;
        long bigNumber = smallNumber;

        System.out.println("\nTask 7: " + bigNumber);


        // TASK 8: Explicit Narrowing
        double d = 9.99;
        int integerNumber = (int) d;

        // Casting removes the decimal part without rounding
        System.out.println("\nTask 8: " + integerNumber);


        // TASK 9: The Modulus Logic
        int value = 157;
        int remainder = value % 2;

        System.out.println("\nTask 9:");
        System.out.println("Remainder: " + remainder);

        if (remainder == 0) {
            System.out.println("Even number");
        } else {
            System.out.println("Odd number");
        }


        // TASK 10: Escape Formatting
        System.out.println("\nTask 10:\n1\t2\t3\n4\t5\t6\n7\t8\t9");


        // TASK 11: Array Bounds
        int[] array = new int[3];

        array[0] = 10;
        array[1] = 20;
        array[2] = 30;

        // array[3] = 40; // Error: ArrayIndexOutOfBoundsException

        System.out.println("\nTask 11: " + array[2]);


        // TASK 12: Array Shortcut
        int[] favoriteNumbers = {7, 14, 21, 28, 35};

        System.out.println("\nTask 12:");
        System.out.println("First: " + favoriteNumbers[0]);
        System.out.println("Last: " + favoriteNumbers[favoriteNumbers.length - 1]);

    }
}
