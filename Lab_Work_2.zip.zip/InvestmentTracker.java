
/**
 * InvestmentTracker calculates compound interest.
 *
 * Financial Formula:
 * Total = Principal * (1 + Rate)^Years
 *
 * This formula calculates the future value
 * of an investment with annual compound interest.
 *
 * @author Timur
 */
public class InvestmentTracker {

    // TASK 3: Financial Calculator

    // Variables
    double principal;
    double interestRate;
    int years;

    // Constructor
    public InvestmentTracker(double principal,
                             double interestRate,
                             int years) {
        this.principal = principal;
        this.interestRate = interestRate;
        this.years = years;
    }

    // Calculate total investment
    public double calculateTotal() {
        return principal * Math.pow(1 + interestRate, years);
    }

    // Main method
    public static void main(String[] args) {

        InvestmentTracker investment =
                new InvestmentTracker(1000, 0.05, 10);

        double total = investment.calculateTotal();

        System.out.println("Investment Report\n");
        System.out.println("Principal: $" + investment.principal);
        System.out.println("Interest Rate: "
                + (investment.interestRate * 100) + "%");
        System.out.println("Years: " + investment.years);

        System.out.printf("Total Investment: $%.2f%n", total);
    }
}
